#ifndef __MY_OLED_H
#define __MY_OLED_H

#define uint8   unsigned char //�Լ��ӵ�
#define uint16   unsigned int   //�Լ��ӵ�
#define int8    char //�Լ��ӵ�
#define int16    int   //�Լ��ӵ�

void oled_fill(char uc_data);
void oled_display_6x8char(uint8 uc_posx, uint8 uc_posy, char uc_data);
void oled_display_6x8str(uint8 uc_posx, uint8 uc_posy, char uc_dataStr[]);
void oled_display_16x8char(uint8 uc_posx, uint8 uc_posy, char uc_data);
void oled_display_16x8char_hl(uint8 uc_posx, uint8 uc_posy, char uc_data);
void oled_display_16x8str(uint8 uc_posx, uint8 uc_posy, char uc_dataStr[]);
void oled_display_16x8str_hl(uint8 uc_posx, uint8 uc_posy, char uc_dataStr[]);
void oled_print_16x8char(uint8 uc_posx, uint8 uc_posy, int8 c_data);
void oled_print_16x8short(uint8 uc_posx, uint8 uc_posy, int16 s_data);
void oled_print_16x8short_hl(uint8 uc_posx, uint8 uc_posy, int16 s_data, int8 bits_num);
void oled_display_6x8char_hl(uint8 uc_posx, uint8 uc_posy, char uc_data);
void oled_display_6x8str_hl(uint8 uc_posx, uint8 uc_posy, char uc_dataStr[]);
void oled_print_char_hl(uint8 uc_posx, uint8 uc_posy, int8 c_data);
void oled_print_short_hl(uint8 uc_posx, uint8 uc_posy, int16 s_data, int8 bits_num);

void oled_print_short(uint8 uc_posx, uint8 uc_posy, int16 s_data);
void oled_print_char(uint8 uc_posx, uint8 uc_posy, char c_data);
void oled_print_16x8short_l(uint8 uc_posx, uint8 uc_posy, int16 s_data);

void LCD_show_chinese(uint8 x , uint8 y, char ch[]);
void LCDPrints(uint8 x, uint8 y, uint8 ch[]);
#endif

